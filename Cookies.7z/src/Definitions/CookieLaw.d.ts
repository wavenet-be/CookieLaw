interface Window
{
    cookieLaw(): void;
    cookieLawPreferences(): void;
}